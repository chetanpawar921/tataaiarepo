package com.tataaia.TataRestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TataRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
